
function submitForm() {
    document.getElementById('message').innerText =
      'Application submitted! Staff will contact you in-game.';
    return false;
}
